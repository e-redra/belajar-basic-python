pi = 22 / 7
def luas_persegi (sisi):
   return sisi * sisi