def greeting(name):
   print("Halo " + name)